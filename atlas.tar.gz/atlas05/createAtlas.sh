#!/bin/bash -e

cd dev

../gen05 -dir gfx -size 128

mv atlas.png ../gfx/
mv atlas.json ../data/
