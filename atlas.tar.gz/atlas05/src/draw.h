/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

void blitAtlasImageScaled(AtlasImage *atlasImage, int x, int y, int w, int h);
void blitAtlasImageRotated(AtlasImage *atlasImage, int x, int y, int angle);
void blitAtlasImage(AtlasImage *atlasImage, int x, int y, int center);
void presentScene(void);
void prepareScene(void);
