/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

#include "common.h"

#include "draw.h"

extern App app;

void prepareScene(void)
{
	SDL_SetRenderDrawColor(app.renderer, 0, 0, 0, 255);
	SDL_RenderClear(app.renderer);
}

void presentScene(void)
{
	SDL_RenderPresent(app.renderer);
}

void blitAtlasImage(AtlasImage *atlasImage, int x, int y, int center)
{
	SDL_Rect  dest;
	SDL_Point p;

	dest.x = x;
	dest.y = y;
	dest.w = atlasImage->rect.w;
	dest.h = atlasImage->rect.h;

	if (!atlasImage->rotated)
	{
		if (center)
		{
			dest.x -= (dest.w / 2);
			dest.y -= (dest.h / 2);
		}

		SDL_RenderCopy(app.renderer, atlasImage->texture, &atlasImage->rect, &dest);
	}
	else
	{
		if (center)
		{
			dest.x -= (dest.h / 2);
			dest.y -= (dest.w / 2);
		}

		p.x = 0;
		p.y = 0;

		dest.y += atlasImage->rect.w;

		SDL_RenderCopyEx(app.renderer, atlasImage->texture, &atlasImage->rect, &dest, -90, &p, SDL_FLIP_NONE);
	}
}

void blitAtlasImageRotated(AtlasImage *atlasImage, int x, int y, int angle)
{
	SDL_Rect dest;

	dest.x = x;
	dest.y = y;
	dest.w = atlasImage->rect.w;
	dest.h = atlasImage->rect.h;

	if (!atlasImage->rotated)
	{
		dest.x -= atlasImage->rect.h / 2;
		dest.y -= atlasImage->rect.w / 2;
	}
	else
	{
		dest.x -= atlasImage->rect.w / 2;
		dest.y -= atlasImage->rect.h / 2;

		angle -= 90;
	}

	SDL_RenderCopyEx(app.renderer, atlasImage->texture, &atlasImage->rect, &dest, angle, NULL, SDL_FLIP_NONE);
}

void blitAtlasImageScaled(AtlasImage *atlasImage, int x, int y, int w, int h)
{
	SDL_Rect  dest;
	SDL_Point p;

	dest.x = x;
	dest.y = y;
	dest.w = w;
	dest.h = h;

	if (atlasImage->rotated)
	{
		p.x = 0;
		p.y = 0;

		dest.y += w;

		SDL_RenderCopyEx(app.renderer, atlasImage->texture, &atlasImage->rect, &dest, -90, &p, SDL_FLIP_NONE);
	}
	else
	{
		SDL_RenderCopy(app.renderer, atlasImage->texture, &atlasImage->rect, &dest);
	}
}
