/*
 * Copyright (C) 2021-2022 Parallel Realities. All rights reserved.
 */

void		setAtlasColor(int r, int g, int b, int a);
AtlasImage *getAtlasImage(char *filename);
void		initAtlas(void);
