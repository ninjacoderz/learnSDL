/*
 * Copyright (C) 2021-2022 Parallel Realities.
 */

#include "common.h"

#include "main.h"

int main(int argc, char *argv[])
{
	return 0;
}
