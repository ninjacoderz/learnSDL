/*
 * Copyright (C) 2021-2022 Parallel Realities.
 */

typedef struct
{
	char		 *filename;
	SDL_Surface *surface;
} Image;
